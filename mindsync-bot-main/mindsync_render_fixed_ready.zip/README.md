# MindSync Bot
Bot de atendimento automatizado para a MindSync.