// app.js de exemplo simplificado
console.log('Bot rodando!');